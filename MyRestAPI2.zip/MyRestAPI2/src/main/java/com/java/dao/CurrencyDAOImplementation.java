package com.java.dao;

import java.util.ArrayList;
import java.util.List;

import com.java.pojo.Currency;

public class CurrencyDAOImplementation implements CurrencyDAO {

	
	List<Currency> currencyList  = new ArrayList<Currency>();
	
	public CurrencyDAOImplementation() {
		
		Currency currency1 = new Currency(1,"INR","USD",5000);
		Currency currency2 = new Currency(2,"INR","EUR",6000);
		Currency currency3 = new Currency(3,"INR","UK",7000);
		Currency currency4 = new Currency(4,"INR","KWD",8000);
		Currency currency5 = new Currency(5,"INR","SGD",9000);
			
		currencyList.add(currency1);
		currencyList.add(currency2);
		currencyList.add(currency3);
		currencyList.add(currency4);
		currencyList.add(currency5);
			
	}
	
	public List<Currency> getAllCurrencies() {
		System.out.println("DAO : returning all currencies...");
		return currencyList;
	}
	
	public Currency getCurrency(int cid) {
		Currency foundCurrency = null;
		for (Currency currency : currencyList) {
			if(cid == currency.getCurrencyId()) {
				foundCurrency = currency;
				break;
			}
		}
	
		return foundCurrency;
	}


}

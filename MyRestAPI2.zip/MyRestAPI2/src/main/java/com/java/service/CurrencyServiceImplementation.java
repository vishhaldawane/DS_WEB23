package com.java.service;

import java.util.List;

import com.java.dao.CurrencyDAO;
import com.java.dao.CurrencyDAOImplementation;
import com.java.pojo.Currency;

public class CurrencyServiceImplementation implements CurrencyService {

	CurrencyDAO currencyDAO = new CurrencyDAOImplementation();
	
	@Override
	public List<Currency> getAllCurrenciesService() {
		
		System.out.println("SERVICE : getAllCurrenciesService()....");
		return currencyDAO.getAllCurrencies();
	}

	@Override
	public Currency getCurrency(int id) {
		System.out.println("SERVICE : getCurrency(int id)....");

		return currencyDAO.getCurrency(id);
	}

}

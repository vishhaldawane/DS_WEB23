import org.junit.jupiter.api.Test;

import com.java.dao.CurrencyDAO;
import com.java.dao.CurrencyDAOImplementation;
import com.java.pojo.Currency;

public class CurrencyDAOTesting {
	
	CurrencyDAO currDAO = new CurrencyDAOImplementation();
	
	@Test
	public void createCurrencyTest() {
		
		Currency curr = new Currency();
		curr.setCurrencyId(26);
		curr.setSourceCurrency("DS");
		curr.setTargetCurrency("INR");
		curr.setLoadFactor(10.5f);
		
		currDAO.insertCurrency(curr);
		
	}
}

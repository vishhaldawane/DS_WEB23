import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.java.exceptions.CurrencyAlreadyExistsException;
import com.java.pojo.Currency;
import com.java.service.CurrencyService;
import com.java.service.CurrencyServiceImplementation;

public class CurrencyServiceTesting {

	
	CurrencyService currService = new CurrencyServiceImplementation();
	
	@Test
	public void addCurrencyServiceTest() throws CurrencyAlreadyExistsException 
	{
		Currency curr = new Currency();
		curr.setCurrencyId(28);
		curr.setSourceCurrency("JK");
		curr.setTargetCurrency("PK");
		curr.setLoadFactor(0.105f);
		
		currService.addCurrencyService(curr);
		
		System.out.println("End successfully...");
	}
	
	@Test
	public void findCurrencyServiceTesting() {
		
		Currency currFound = currService.getCurrency(50);
		//Assertions.assertTrue(currFound!=null);
		System.out.println("currFound : "+currFound);
	}
	
	
}

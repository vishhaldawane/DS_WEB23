import org.junit.jupiter.api.Test;

import com.java.dao.CurrencyDAO;
import com.java.dao.CurrencyDAOImplementation;
import com.java.pojo.Currency;

public class CurrencyDAOTesting {
	
	CurrencyDAO currDAO = new CurrencyDAOImplementation();
	
	@Test
	public void createCurrencyTest() {
		
		Currency curr = new Currency();
		curr.setCurrencyId(26);
		curr.setSourceCurrency("DS");
		curr.setTargetCurrency("INR");
		curr.setLoadFactor(10.5f);
		
		currDAO.insertCurrency(curr);
		
	}
	@Test
	public void updateCurrencyTest() {
		Currency curr = new Currency();
		curr.setCurrencyId(29);
		curr.setSourceCurrency("okok");
		curr.setTargetCurrency("notoknotok");
		curr.setLoadFactor(222);
		
		currDAO.updateCurrency(curr);
	}
	
	@Test
	public void deleteCurrencyTest() {
		
		currDAO.deleteCurrency(20);
		currDAO.deleteCurrency(21);
		currDAO.deleteCurrency(22);
		currDAO.deleteCurrency(23);
		currDAO.deleteCurrency(24);
		currDAO.deleteCurrency(25);
		currDAO.deleteCurrency(26);
		currDAO.deleteCurrency(27);
		currDAO.deleteCurrency(28);
		currDAO.deleteCurrency(29);
		
	}
}

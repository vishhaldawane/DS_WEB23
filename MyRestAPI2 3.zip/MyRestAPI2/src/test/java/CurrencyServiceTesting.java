import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.java.exceptions.CurrencyAlreadyExistsException;
import com.java.pojo.Currency;
import com.java.service.CurrencyService;
import com.java.service.CurrencyServiceImplementation;

public class CurrencyServiceTesting {

	
	CurrencyService currService = new CurrencyServiceImplementation();
	
	@Test
	public void addCurrencyServiceTest() throws CurrencyAlreadyExistsException 
	{
		Currency curr = new Currency();
		curr.setCurrencyId(28);
		curr.setSourceCurrency("JK");
		curr.setTargetCurrency("PK");
		curr.setLoadFactor(0.105f);
		
		currService.addCurrencyService(curr);
		
		System.out.println("End successfully...");
	}
	
	@Test
	public void findCurrencyServiceTest() {
		
		Currency currFound = currService.getCurrency(50);
		//Assertions.assertTrue(currFound!=null);
		System.out.println("currFound : "+currFound);
	}
	
	@Test
	public void modifyCurrencyServiceTest() {
		
		Currency curr = new Currency();
		curr.setCurrencyId(199);
		curr.setSourceCurrency("OK");
		curr.setTargetCurrency("NOTOK");
		curr.setLoadFactor(111);
		
		currService.modifyCurrencyService(curr);
		System.out.println("Service has Modified It");
	}
	
	@Test
	public void removeCurrencyServiceTest() {
		
		
		
		currService.removeCurrencyService(19);
		System.out.println("Service has deleted It");
	}
	
	@Test
	public void calculateCurrencyConversionTest() {
		
		double value = currService.calculateCurrencyService("USD","INR",5000);
		System.out.println("Converted amount : "+value);
	}
	
}
